<template>
  <div class="min-w-[750px]" :style="{ height: clientHeight + 'px' }">
    <NavBar />

    <div
      v-show="store.navView === 'solver'"
      class="flex w-full mx-auto max-w-screen-xl"
      style="height: calc(100% - 2.5rem)"
    >
      <SideBar style="height: calc(100% - 2rem)" :sideObj="sideObj" />

      <div
        class="flex-grow my-4 px-6 pt-2 overflow-y-auto right-module"
        style="height: calc(100% - 2rem)"
      >

        <div v-show="store.sideView === 'oop-range'">
          <RangeEditor :player="0" :range_str="oop_range_str" />
        </div>
        <div v-show="store.sideView === 'ip-range'">
          <RangeEditor :player="1" :range_str="ip_range_str" />
        </div>
        <div v-show="store.sideView === 'board'">
          <BoardSelector />
        </div>
        <div v-show="store.sideView === 'tree-config'">
          <TreeConfig :moneyObj="moneyObj" />
        </div>
        <div v-show="store.sideView === 'bunching'">
          <BunchingEffect />
        </div>
        <div v-show="store.sideView === 'run-solver'">
          <RunSolver />
        </div>
      </div>
    </div>

    <div
      v-show="store.navView === 'results'"
      style="height: calc(max(100%, 720px) - 2.5rem)"
    >
      <ResultViewer />
    </div>
  </div>
</template>

<script setup lang="ts">
import { hexCharCodeToStr } from '../convertUtil.js'
import { computed, ref, onMounted } from "vue";
import { useStore } from "../store";

import NavBar from "./NavBar.vue";
import SideBar from "./SideBar.vue";
import RangeEditor from "./RangeEditor.vue";
import BoardSelector from "./BoardSelector.vue";
import TreeConfig from "./TreeConfig.vue";
import BunchingEffect from "./BunchingEffect.vue";
import RunSolver from "./RunSolver.vue";
import ResultViewer from "./ResultViewer.vue";

const store = useStore();
const header = computed(() => store.headers[store.sideView].join(" > "));
const isFinshed = ref(false)
const clientHeight = ref(0);
const updateClientHeight = () => {
  clientHeight.value = document.documentElement.clientHeight - 0.01;
};
const ip_range_str = ref('')
const oop_range_str = ref('')
const moneyObj = ref({
  defaultMoney: 0,
  countMoney: 0
})
const sideObj = ref({
  oop_title: '',
  ip_title: ''
})
updateClientHeight();
window.addEventListener("resize", updateClientHeight);
// 获取URL参数
const getQueryString = (name: any) => {
  var reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)', 'i');
  var r = window.location.search.substr(1).match(reg);
  if (r != null) {
      return unescape(r[2]);
  }
  return null;
}
onMounted(() => {
  console.log('aa', import.meta.env.MODE)
  if (import.meta.env.MODE == 'development') {
    isFinshed.value = true
    if (getQueryString('code')) {
      let params = JSON.parse(hexCharCodeToStr(getQueryString('code')))
      console.log('params', params)
      ip_range_str.value = params.ip_range_str
      oop_range_str.value = params.oop_range_str
      moneyObj.value = {
        defaultMoney:  params.defaultMoney,
        countMoney:  params.countMoney
      }
      sideObj.value = {
        oop_title: params.oop_title,
        ip_title: params.ip_title,
      }
      console.log('paramsxxxxx', params)
    }
  } else {
    if (getQueryString('code')) {
      isFinshed.value = true
      let params = JSON.parse(hexCharCodeToStr(getQueryString('code')))
      console.log('params', params)
      ip_range_str.value = params.ip_range_str
      oop_range_str.value = params.oop_range_str
      moneyObj.value = {
        defaultMoney:  params.defaultMoney,
        countMoney:  params.countMoney
      }
      sideObj.value = {
        oop_title: params.oop_title,
        ip_title: params.ip_title,
      }
      console.log('paramsxxxxx', params)
    } else {
      location.href = 'https://gtosolver.cn/#/mobile-login'
    }
  }
})
</script>
