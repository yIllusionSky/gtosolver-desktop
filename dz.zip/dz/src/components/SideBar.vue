<template>
  <aside class="flex flex-col shrink-0 w-56 my-4 overflow-y-auto border-r-2 sider-class">
    <button
      :class="itemStyle('oop-range')"
      @click="store.sideView = 'oop-range'"
    >
      {{ oop_title }}
      <!-- <span class="flex my-2 justify-center">
        <RangeMiniViewer :player="0" />
      </span> -->
    </button>

    <button :class="itemStyle('ip-range')" @click="store.sideView = 'ip-range'">
      {{ ip_title }}
      <!-- <span class="flex my-2 justify-center">
        <RangeMiniViewer :player="1" />
      </span> -->
    </button>

    <button :class="itemStyle('board')" @click="store.sideView = 'board'">
      选择翻牌
      <!-- <span class="flex mt-1 justify-center font-semibold">
        <span
          v-for="(item, i) in boardTexts"
          :key="i"
          :class="
            'inline-block ' + (i === 3 ? 'mx-1 ' : 'mx-0.5 ') + item.colorClass
          "
        >
          {{ item.rank + item.suit }}
        </span>
      </span> -->
    </button>

    <button
      :class="itemStyle('tree-config')"
      @click="store.sideView = 'tree-config'"
    >
      参数调整
    </button>

    <!-- <button :class="itemStyle('bunching')" @click="store.sideView = 'bunching'">
      Bunching Effect
    </button> -->

    <button
      :class="itemStyle('run-solver')"
      @click="store.sideView = 'run-solver'"
    >
      运行解算器
    </button>
  </aside>
</template>

<script setup lang="ts">
import { computed, ref, watch } from "vue";
import { SideView, useStore, useConfigStore } from "../store";
import { cardText } from "../utils";

import RangeMiniViewer from "./RangeMiniViewer.vue";
const props = withDefaults(
  defineProps<{ sideObj?: object }>(),
  {}
);
const store = useStore();
const config = useConfigStore();

const itemStyle = (view: SideView) => {
  return (
    "side-bar-item " + (view === store.sideView ? "font-bold bg-blue-100" : "")
  );
};

const boardTexts = computed(() => {
  if (config.board.length === 0) {
    return [{ rank: "-", suit: "", colorClass: "text-black" }];
  } else {
    return config.board.map(cardText);
  }
});
const oop_title = ref('')
const ip_title = ref('')
watch(
  () => props.sideObj,
  (newValue: any) => {
    oop_title.value = newValue.oop_title
    ip_title.value = newValue.ip_title
  }
)
</script>

<style scoped>
.side-bar-item {
  @apply block mx-2 my-[0.1875rem] px-4 py-2.5 rounded-3xl;
  @apply text-left text-[1.0625rem] select-none;
  @apply transition-colors hover:bg-blue-100;
}
</style>
