/**
 * 字符串转十六进制-中文兼容
 * @param str 原始字符串
 * @returns
 */
 export function strToHexCharCode(str) {
  const charBuf = writeUTF(str, true)
  let re = ''
  for (let i = 0; i < charBuf.length; i++) {
    let x = (charBuf[i] & 0xff).toString(16)
    if (x.length === 1) {
      x = '0' + x
    }
    re += x
  }
  return re
}

/**
 * 十六进制转原始字符串-中文兼容
 * @param hexCharCodeStr 十六进制字符串
 * @returns
 */
export function hexCharCodeToStr(hexCharCodeStr) {
  const buf = []
  for (let i = 0; i < hexCharCodeStr.length; i += 2) {
    buf.push(parseInt(hexCharCodeStr.substring(i, i + 2), 16))
  }
  return readUTF(buf)
}

const writeUTF = function (str, isGetBytes) {
  const back = []
  let byteSize = 0
  for (let i = 0; i < str.length; i++) {
    const code = str.charCodeAt(i)
    if (0x00 <= code && code <= 0x7f) {
      byteSize += 1
      back.push(code)
    } else if (0x80 <= code && code <= 0x7ff) {
      byteSize += 2
      back.push(192 | (31 & (code >> 6)))
      back.push(128 | (63 & code))
    } else if ((0x800 <= code && code <= 0xd7ff) || (0xe000 <= code && code <= 0xffff)) {
      byteSize += 3
      back.push(224 | (15 & (code >> 12)))
      back.push(128 | (63 & (code >> 6)))
      back.push(128 | (63 & code))
    }
  }
  for (let i = 0; i < back.length; i++) {
    back[i] &= 0xff
  }
  if (isGetBytes) {
    return back
  }
  if (byteSize <= 0xff) {
    return [0, byteSize].concat(back)
  } else {
    return [byteSize >> 8, byteSize & 0xff].concat(back)
  }
}

const readUTF = function (arr) {
  if (typeof arr === 'string') {
    return arr
  }
  let UTF = ''
  const _arr = arr
  for (let i = 0; i < _arr.length; i++) {
    const one = _arr[i].toString(2),
      v = one.match(/^1+?(?=0)/)
    if (v && one.length == 8) {
      const bytesLength = v[0].length
      let store = _arr[i].toString(2).slice(7 - bytesLength)
      for (let st = 1; st < bytesLength; st++) {
        store += _arr[st + i].toString(2).slice(2)
      }
      UTF += String.fromCharCode(parseInt(store, 2))
      i += bytesLength - 1
    } else {
      UTF += String.fromCharCode(_arr[i])
    }
  }
  return UTF
}
