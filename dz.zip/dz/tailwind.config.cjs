/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["src/**/*.ts", "src/**/*.vue"],
  plugins: [require("@tailwindcss/forms")],
};
